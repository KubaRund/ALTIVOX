param([string]$DataDirectory = "$PSScriptRoot/osrm-data", [string]$Image = 'ghcr.io/project-osrm/osrm-backend@sha256:55dbfd47d984c2cacd64e32901b4321c86b5ec761438e69aa053dc78698a786f')
$ErrorActionPreference = 'Stop'
New-Item -ItemType Directory -Force -Path $DataDirectory | Out-Null
$resolvedData = (Resolve-Path -LiteralPath $DataDirectory).Path
$pbf = Join-Path $resolvedData 'czech-republic-latest.osm.pbf'
if (!(Test-Path -LiteralPath $pbf)) {
    Invoke-WebRequest 'https://download.geofabrik.de/europe/czech-republic-latest.osm.pbf' -OutFile $pbf
}
Get-FileHash -LiteralPath $pbf -Algorithm SHA256 | Format-List | Out-File (Join-Path $resolvedData 'graph-version.txt')
function Invoke-Docker([string[]]$DockerArguments) {
    & docker @DockerArguments
    if ($LASTEXITCODE -ne 0) { throw "Docker failed: $DockerArguments" }
}
Invoke-Docker @('run','--rm','-v',"${resolvedData}:/data",$Image,'osrm-extract','-p','/opt/car.lua','/data/czech-republic-latest.osm.pbf')
Invoke-Docker @('run','--rm','-v',"${resolvedData}:/data",$Image,'osrm-partition','/data/czech-republic-latest.osrm')
Invoke-Docker @('run','--rm','-v',"${resolvedData}:/data",$Image,'osrm-customize','/data/czech-republic-latest.osrm')
Write-Host 'OSRM starts in foreground. Stop using Ctrl+C. Graph hash: osrm-data/graph-version.txt'
Invoke-Docker @('run','--rm','-p','127.0.0.1:5000:5000','-v',"${resolvedData}:/data",$Image,'osrm-routed','--algorithm','mld','--max-table-size','100','/data/czech-republic-latest.osrm')
