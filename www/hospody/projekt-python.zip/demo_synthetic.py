"""Explicitly synthetic fallback and reproducible end-to-end numerical test.
Runs the production optimizer against a directed model road network, not OSM.
"""
import argparse, heapq, json, math, pathlib
from unittest.mock import patch
import pubroute

def run():
    root=pathlib.Path(__file__).resolve().parent
    coords=[(14.40+x*.004,50.07+y*.003) for y in range(4) for x in range(4)]
    graph={i:[] for i in range(16)}
    for i in graph:
        x=i%4; y=i//4
        # East/west edges alternate direction by row. North/south bidirectional.
        if x<3:
            a,b=(i,i+1) if y%2==0 else (i+1,i)
            graph[a].append(b)
        if y<3: graph[i].append(i+4); graph[i+4].append(i)
    def path(a,b):
        queue=[(0,a,[a])]; seen=set()
        while queue:
            c,v,order=heapq.heappop(queue)
            if v in seen: continue
            seen.add(v)
            if v==b: return c,order
            for w in graph[v]:
                d=pubroute.hav({'lon':coords[v][0],'lat':coords[v][1]},{'lon':coords[w][0],'lat':coords[w][1]})
                heapq.heappush(queue,(c+d,w,order+[w]))
        raise RuntimeError('Model disconnected')
    def match(lon,lat): return min(range(16),key=lambda i:(coords[i][0]-lon)**2+(coords[i][1]-lat)**2)
    def mock_get(self,url):
        self.calls+=1
        raw=url.split('?')[0].split('/')[-1]; ids=[match(*map(float,s.split(','))) for s in raw.split(';')]
        if url.startswith('/nearest'):
            i=ids[0]; return {'code':'Ok','waypoints':[{'location':coords[i],'distance':0,'hint':'model-'+str(i)}]}
        if url.startswith('/table'):
            distances=[[path(a,b)[0] for b in ids] for a in ids]
            return {'code':'Ok','distances':distances,'durations':[[d/8.333333 for d in row] for row in distances]}
        distance,order=path(ids[0],ids[-1])
        return {'code':'Ok','routes':[{'distance':distance,'duration':distance/8.333333,'geometry':{'type':'LineString','coordinates':[coords[i] for i in order]}}]}
    poi_ids=[0,2,3,5,7,8,10,12,14,15,1,9]
    source={'source':'SYNTHETIC MODEL — invented POIs and directed grid streets, NOT OSM','scope':'synthetic','synthetic':True,'points':[{'id':'demo/'+str(i),'name':'Modelový podnik '+str(k+1),'amenity':['pub','bar','biergarten'][k%3],'lon':coords[i][0],'lat':coords[i][1]} for k,i in enumerate(poi_ids)]}
    pubroute.write(root/'synthetic-pois.json',source)
    args=argparse.Namespace(input=str(root/'synthetic-pois.json'),output=str(root/'synthetic-demo'),osrm='http://synthetic-model.invalid',graph_version='invented-directed-grid-v1',objective='duration',cluster_size=4,max_snap=250,limit=None,closed=False,allow_partial=False,delay=0)
    with patch.object(pubroute.Router,'get',mock_get): pubroute.optimize(args)
    result=json.loads((root/'synthetic-demo/result.json').read_text(encoding='utf-8'))
    assert len(set(result['order']))==12 and len(result['edges'])==11
    assert result['metrics']['coverage_selected']==1
    assert all(len(e['geometry']['coordinates'])>=2 for e in result['edges'])
    print('End-to-end synthetic demonstration verified; no real-road claim.')

if __name__=='__main__': run()
