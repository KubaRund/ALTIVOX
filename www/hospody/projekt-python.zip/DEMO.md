# Ověřená demonstrace — 13. 10. 2026

Skutečné OSM API vrátilo 27 objektů v centru Prahy. Z nich bylo deterministicky vybráno 12 podle OSM ID. Data jsou v `demo-api-pois.json`, původní odpověď v `demo-osm-map.xml`. Automobilové cesty byly získány z `https://router.project-osrm.org`, přesnou verzi veřejného grafu server neoznamuje. Jedná se o skutečná data a skutečné silniční geometrie, nikoli celostátní výsledek. Ve výběru jsou pub a bar; podporu biergarten obsahuje dotaz a syntetický test, skutečný výběr tuto kategorii neobsahuje.

| Konfigurace | Pokrytí výběru | Silniční délka | Doba jízdy | První běh |
|---|---:|---:|---:|---:|
| Hierarchie, cluster 4 | 12/12 | 3,5389 km | 7,5017 min | 32,58 s, 29 HTTP |
| Jedna matice, cluster 48 | 12/12 | 1,9263 km | 4,2783 min | 28,45 s, 25 HTTP |

Porovnání ukazuje cenu malých geografických clusterů: hustá varianta je v tomto výřezu o 43,0 % rychlejší a o 45,6 % kratší. Není to doložené globální optimum. Pro malé výřezy používejte jednu matici, pro velká data hierarchii a porovnejte více velikostí clusteru. Největší přichycení k silnici bylo 18,55 m; žádný vybraný bod nebyl vyřazen. Hodiny nezahrnují návštěvy ani provoz. Lokální přesuny v tomto malém výběru nezlepšily multistart greedy okruh; jejich správnost je ověřena na dalších asymetrických testech.

Otevřete `real-demo-dense/map.html` pro lepší nalezenou trasu, `real-demo/map.html` pro ukázku skutečné dvouúrovňové hierarchie. Obě mají vložená route data; internet potřebují mapové dlaždice a Leaflet. Prohlížeč Edge ověřil načtení mapové knihovny, změnu kategorie, hledání, přepnutí trasy, posuvník zastávek a návrat na celou mapu. Na šířce 375 px nebyl vodorovný overflow ani chyba JavaScriptu.

Reprodukce z uložených dat (v adresáři projektu):

```powershell
python pubroute.py optimize --input demo-api-pois.json --output real-demo --osrm https://router.project-osrm.org --graph-version public-osrm-observed-2026-10-13-unknown-build --cluster-size 4 --limit 12 --delay 1
python pubroute.py optimize --input demo-api-pois.json --output real-demo-dense --osrm https://router.project-osrm.org --graph-version public-osrm-observed-2026-10-13-unknown-build --cluster-size 48 --limit 12 --delay 1
```

Uložená cache dovoluje reprodukci bez nových HTTP dotazů. Pro čerstvý veřejný graf použijte nový identifikátor i nový výstupní adresář. `demo_collect_osm.py` stáhne nový malý výřez přímo z OSM API; pro celou ČR použijte Overpass a lokální OSRM podle README. Náhradní Overpass nakonec také vrátil 251 skutečných objektů ze širšího výřezu; jsou v `demo-pois.json` a původním raw JSON, ale v této demonstraci nebyly routovány.

`synthetic-demo/map.html` je dodatečný výslovně označený model s vymyšlenými podniky a jednosměrnou sítí. `python demo_synthetic.py` spustí celý produkční optimalizátor na modelu a ověří pokrytí 12/12, 11 úseků a existenci jejich geometrie. Modelové hodnoty nejsou čísly pro ČR.

Pět numerických unit testů prošlo. Lokální Docker/OSRM pro ČR nebyl spuštěn: Docker zde není instalovaný. Celostátní kvalita řešení, rychlost ani paměťové nároky proto nejsou zde benchmarkovány.
