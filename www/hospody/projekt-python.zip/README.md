# Automobilová trasa po pub / bar / biergarten v ČR

Python 3.10+; hlavní program používá pouze standardní knihovnu. Data: objekty OpenStreetMap s přesně `amenity=pub`, `bar`, `biergarten`, nikoli všechny existující podniky v zemi. Pořadí je heuristické, bez důkazu globálního optima.

## Spuštění pro ČR

V příkazech pracujte ve složce tohoto projektu. Na Windows lze místo `python` použít `py -3`. Docker Desktop musí mít zapnuté linuxové kontejnery. Příprava celé ČR potřebuje dostatek RAM a disku a může trvat dlouho; na tomto počítači nebyla provedena.

1. V prvním terminálu připravte lokální OSRM a nechte jej běžet:

```powershell
powershell -ExecutionPolicy Bypass -File ./setup_osrm.ps1
```

Skript stáhne Geofabrik PBF ČR, zapíše SHA256 a spustí extract → partition → customize s `car.lua`, poté server MLD na `127.0.0.1:5000`. Image je připnutý na digest oficiální verze 26.10 z registru OSRM. Volitelně změňte `-Image`; při změně dat nebo profilu změňte identifikátor grafu v dalších příkazech. Skript není zde end-to-end ověřen, protože Docker není instalovaný.

2. V druhém terminálu načtěte POI a počítejte:

```powershell
python pubroute.py fetch --output pois-cz.json
python pubroute.py optimize --input pois-cz.json --output cz-run --graph-version "SHA256-PBF-plus-image-digest-car-profile" --cluster-size 48
```

Nahraďte hodnotu `--graph-version` skutečným hashem z `osrm-data/graph-version.txt` a verzí image/profilu. Identifikátor tvoří součást klíče SQLite cache; používání stejného identifikátoru po změně grafu vede ke starým odpovědím. Načtení POI a silnice mají nezávislé časové snímky: datové razítko Overpass je v JSON; verze grafu má být ve stejném období. Overpass endpoint lze přepnout pomocí `--overpass`. Serverový `remark` znamená neúplný výstup a program skončí chybou.

3. Otevřete `cz-run/map.html`, nebo spusťte `python -m http.server 8000` a otevřete `http://localhost:8000/cz-run/map.html`.

## Volby a význam optimalizace

Výchozí cíl je čas jízdy. `--objective distance` minimalizuje **délky nejrychlejších cest vrácených OSRM**, nikoli zaručeně nejkratší silniční spojení dvojic. Skutečné nejkratší automobilové cesty vyžadují odpovídající metriku routovacího profilu a nové předzpracování; samotný přepínač nestačí. Nezaměňujte heuristickou optimalizaci pořadí s přesným řešením TSP.

Výchozí trasa je otevřená a nemá pevný začátek ani konec. Algoritmus sestaví orientovaný okruh a odstraní jeho nejdražší hranu; tím vybírá oba konce v rámci nalezeného okruhu. Není to přesný řešič problému s volnými konci. `--closed` ponechá okruh; jeho počáteční index je pouze způsob zobrazení.

`--limit 12` vytvoří deterministický výřez podle OSM ID, **není reprezentativním vzorkem ČR**. `fetch --bbox south,west,north,east` získá geografický výřez. `--max-snap 250` omezuje vzdálenost podniku od automobilové sítě v metrech. Body mimo limit se uloží do `rejected.json` a výpočet se zastaví. `--allow-partial` dovolí výslovně částečný výsledek. Nedostupné spojení v matici je nekonečné; program je nenahradí vzdušnou čarou ani tiše nevynechá. Selhání greedy konstrukce není důkaz, že neexistuje jiná proveditelná trasa.

Uzly zůstávají na skutečných souřadnicích; cesty končí na přístupovém bodě OSRM. U budov a relací jde o bounding-box center z Overpass, který nemusí být vchodem. OSM objekty jsou deduplikované podle type/id, nikoli podle podniku; budova a bod mohou označovat stejný podnik. Otevírací doby, legalita parkování, provoz, zastávky a přesuny pěšky nejsou v cílové funkci. PBF ČR může omezit cesty, které přirozeně vedou přes zahraničí; pro takové trasy použijte širší konzistentní výřez v OSRM. Trasa nemá výslovnou podmínku zůstat uvnitř hranic.

## Hierarchická heuristika a škálování

Geografické dělení podle nejdelší osy vytváří skupiny do B bodů. V každé skupině OSRM table vrátí orientovanou matici. Greedy konstrukce z každého počátku vybírá nejlepší okruh; až 20 průchodů přesunů jednoho uzlu zlepšuje orientované náklady bez předpokladu symetrie. Největší lokální hrana se rozřízne. Reprezentanti skupin (nejbližší centroidu) se řadí rekurzivně stejným postupem. Skupiny se propojí a skutečná geometrie každé hrany se vypočte přes route. Největší globální hrana se pro otevřenou trasu odstraní.

Matice používají zhruba O(N·B) prvků namísto O(N²). Multistart greedy zhruba O(N·B²), lokální přesuny O(20·N·B). Graf OSRM má vlastní nároky. Spojení skupin jsou heuristická; nejsou optimalizována společně s vnitřními cestami. S rostoucí velikostí clusteru se mění kvalita i náklady. Porovnejte několik B a cílů podle finálních metrik, ne podle místních matic.

Nearest i route se volají postupně, zhruba 2N požadavků, plus tabulky a úrovně hierarchie. To může pro celou ČR trvat dlouho. SQLite ukládá úspěšné odpovědi pro opakované spuštění; změna pořadí může vyžadovat další route odpovědi. Celostátní režim provozujte na vlastním OSRM. Veřejný OSRM je jen pro malou demonstraci, nikdy pro celou ČR. `--delay` omezuje frekvenci požadavků.

## Metriky a artefakty

- `result.json`: zdroj, dotaz, razítko OSM, graf, cíl, pořadí, souřadnice a geometrie, počet vybraných/navštívených/vyřazených bodů, pokrytí výběru, km, hodiny, max. snap, čas výpočtu a počet HTTP/cache zásahů.
- `matrix_levels`: náklady greedy a lokálně zlepšených **uzavřených** okruhů jednotlivých skupin a reprezentantů. Nejde o globální baseline a hodnoty se nesmějí sčítat jako celostátní úspora.
- `route.geojson`: skutečné orientované OSRM úseky, bez syntetických spojnic. Délka i čas finální trasy jsou součty odpovědí route, nikoli vzdušné vzdálenosti nebo odhady z table.
- `map.html`: vložená data, zoom, posun, vyhledávání, filtr kategorií, viditelnost trasy a posuvník pořadí návštěv. Leaflet a podkladové dlaždice potřebují internet; samotná route data jsou vložená.
- `rejected.json`: vyřazené OSM objekty a důvody. `pois.json.raw.json`: původní odpověď Overpass pro audit.

Pokrytí znamená podíl vybraných OSM objektů, ne podíl všech reálných hospod. Celostátní výpočet nepovažujte za ověřený bez kontroly nezpracovaných bodů, kvality OSM a konkrétního snapshotu silnic.

## Testy

```powershell
python -m unittest discover -s . -v
```

Testy ověřují asymetrické přesuny pro otevřenou i uzavřenou trasu, malé přesné optimum enumerací, nedostupná spojení, rekurzivní pokrytí všech ID, převod null a invalidaci cache změnou grafu. Skutečná ukázka a její omezení jsou uvedeny v `DEMO.md`.

## Zdroje a licence dat

[OSRM API](https://project-osrm.org/docs/v26.5.0/http), [oficiální OSRM / Docker postup](https://github.com/Project-OSRM/osrm-backend), [OSRM container registry](https://github.com/project-osrm/osrm-backend/pkgs/container/osrm-backend), [Geofabrik ČR](https://download.geofabrik.de/europe/czech-republic.html), [Overpass QL](https://wiki.openstreetmap.org/wiki/Overpass_API/Overpass_QL). Data © OpenStreetMap contributors, [ODbL](https://www.openstreetmap.org/copyright). Při sdílení odvozených dat zachovejte atribuci a podmínky ODbL.
