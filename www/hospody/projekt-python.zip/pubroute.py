"""OSM pub/bar/biergarten routing, Python 3.10+, standard library only."""
import argparse, datetime, hashlib, json, math, pathlib, sqlite3, time, urllib.parse, urllib.request, urllib.error

KINDS = {'pub', 'bar', 'biergarten'}

def write(path, data):
    path = pathlib.Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')

def request(url, data=None, timeout=120):
    req = urllib.request.Request(url, data=data, headers={'User-Agent':'CZPubRoute/1.0 (OSM research)', 'Content-Type':'application/x-www-form-urlencoded'})
    for attempt in range(3):
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r: return json.load(r)
        except urllib.error.HTTPError as e:
            if e.code == 400:
                try: return json.loads(e.read())
                except (ValueError,UnicodeError): raise e
            if attempt == 2: raise
            time.sleep(2 ** attempt)
        except Exception:
            if attempt == 2: raise
            time.sleep(2 ** attempt)

def fetch(args):
    scope = '(area.cz)'
    prefix = 'area["ISO3166-1"="CZ"]["admin_level"="2"]->.cz;'
    if args.bbox:
        b = [float(x) for x in args.bbox.split(',')]
        if len(b)!=4 or b[0]>=b[2] or b[1]>=b[3]: raise ValueError('bbox: south,west,north,east')
        scope = '(' + ','.join(map(str,b)) + ')'; prefix = ''
    query = '[out:json][timeout:180];' + prefix + 'nwr["amenity"~"^(pub|bar|biergarten)$"]' + scope + ';out center tags;'
    raw = request(args.overpass, urllib.parse.urlencode({'data':query}).encode(), 210)
    if raw.get('remark'): raise RuntimeError('Overpass incomplete response: '+raw['remark'])
    points=[]; seen=set(); missing=0
    for el in raw['elements']:
        key=f"{el['type']}/{el['id']}"; pos=el.get('center', el); tags=el.get('tags',{})
        if key in seen or tags.get('amenity') not in KINDS: continue
        seen.add(key)
        if 'lat' not in pos or 'lon' not in pos: missing+=1; continue
        points.append({'id':key,'name':tags.get('name',key),'amenity':tags['amenity'],'lat':pos['lat'],'lon':pos['lon']})
    points.sort(key=lambda p:p['id'])
    write(args.output, {'source':'OpenStreetMap / Overpass','endpoint':args.overpass,'query':query,'downloaded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'osm_timestamp':raw.get('osm3s',{}).get('timestamp_osm_base'),'scope':args.bbox or 'CZ administrative area','missing_coordinates':missing,'points':points})
    write(str(args.output)+'.raw.json',raw)
    print(f'Fetched {len(points)} OSM objects -> {args.output}',flush=True)

def hav(a,b):
    x,y=map(math.radians,[a['lat'],b['lat']]); dx=y-x; dy=math.radians(b['lon']-a['lon'])
    return 6371000*2*math.asin(min(1,math.sqrt(math.sin(dx/2)**2+math.cos(x)*math.cos(y)*math.sin(dy/2)**2)))

class Router:
    def __init__(self,url,cache,version,delay=0):
        self.url=url.rstrip('/'); self.delay=delay; self.calls=0; self.hits=0
        self.db=sqlite3.connect(cache); self.db.execute('CREATE TABLE IF NOT EXISTS responses (k TEXT PRIMARY KEY, v TEXT)')
        self.version=version
    def get(self,path):
        key=hashlib.sha256((self.url+'|'+self.version+'|'+path).encode()).hexdigest()
        row=self.db.execute('SELECT v FROM responses WHERE k=?',(key,)).fetchone()
        if row: self.hits+=1; return json.loads(row[0])
        if self.delay: time.sleep(self.delay)
        result=request(self.url+path); self.calls+=1
        if result.get('code')!='Ok': raise RuntimeError('OSRM: '+str(result))
        self.db.execute('INSERT OR REPLACE INTO responses VALUES (?,?)',(key,json.dumps(result))); self.db.commit()
        return result
    def coords(self,points): return ';'.join(f"{p['lon']:.7f},{p['lat']:.7f}" for p in points)
    def params(self,points):
        d={'radiuses':';'.join('100' for _ in points)}
        if all(p.get('hint') for p in points): d['hints']=';'.join(p['hint'] for p in points)
        return d
    def table(self,points,objective):
        q=self.params(points); q['annotations']='duration,distance'
        r=self.get('/table/v1/driving/'+self.coords(points)+'?'+urllib.parse.urlencode(q))
        return [[math.inf if x is None else x for x in row] for row in r['durations' if objective=='duration' else 'distances']]
    def route(self,points):
        q=self.params(points); q.update({'overview':'full','geometries':'geojson','steps':'false','continue_straight':'false'})
        return self.get('/route/v1/driving/'+self.coords(points)+'?'+urllib.parse.urlencode(q))['routes'][0]

def cost(order,m,closed=True):
    pairs=list(zip(order,order[1:]))
    if closed and len(order)>1: pairs.append((order[-1],order[0]))
    return sum(m[a][b] for a,b in pairs)

def improve(order,m,closed=True,passes=20):
    """Directed node relocation: no symmetric-edge assumption, endpoints can move."""
    order=list(order); n=len(order)
    for _ in range(passes):
        best_delta=-1e-7; best=None
        for i,x in enumerate(order):
            prev=order[i-1] if i or closed else None
            nxt=order[(i+1)%n] if i+1<n or closed else None
            removed=(m[prev][x] if prev is not None else 0)+(m[x][nxt] if nxt is not None else 0)
            added=m[prev][nxt] if prev is not None and nxt is not None else 0
            if not math.isfinite(removed+added): continue
            rem=order[:i]+order[i+1:]
            for j in range(len(rem)+1):
                if closed and j==len(rem): continue
                a=rem[j-1] if j or closed else None; b=rem[j] if j<len(rem) else (rem[0] if closed else None)
                old=m[a][b] if a is not None and b is not None else 0
                new=(m[a][x] if a is not None else 0)+(m[x][b] if b is not None else 0)
                delta=added-removed+new-old
                if math.isfinite(delta) and delta<best_delta: best_delta=delta; best=(rem,j,x)
        if best is None: break
        rem,j,x=best; order=rem[:j]+[x]+rem[j:]
    return order

def solve_matrix(m):
    n=len(m)
    if n<2: return list(range(n)),0,0
    candidates=[]
    for start in range(n):
        order=[start]; todo=set(range(n))-{start}
        while todo:
            nxt=min(todo,key=lambda x:(m[order[-1]][x],x)); order.append(nxt); todo.remove(nxt)
        if math.isfinite(cost(order,m)): candidates.append(order)
    if not candidates: raise RuntimeError('No finite greedy tour in cluster; unreachable or heuristic dead end. Split/inspect graph; nothing silently omitted.')
    baseline=min(candidates,key=lambda o:cost(o,m)); refined=improve(baseline,m)
    return refined,cost(baseline,m),cost(refined,m)

def partition(indices,points,size):
    if len(indices)<=size: return [indices]
    lat=[points[i]['lat'] for i in indices]; lon=[points[i]['lon'] for i in indices]
    axis='lat' if max(lat)-min(lat)>(max(lon)-min(lon))*math.cos(math.radians(sum(lat)/len(lat))) else 'lon'
    ordered=sorted(indices,key=lambda i:(points[i][axis],points[i]['id'])); mid=len(ordered)//2
    return partition(ordered[:mid],points,size)+partition(ordered[mid:],points,size)

def hierarchy(indices,points,router,objective,size,stats):
    if len(indices)<=size:
        m=router.table([points[i] for i in indices],objective)
        order,before,after=solve_matrix(m); stats.append({'size':len(indices),'before':before,'after':after})
        if len(order)>1:
            cut=max(range(len(order)),key=lambda j:m[order[j]][order[(j+1)%len(order)]])
            order=order[cut+1:]+order[:cut+1]
        return [indices[i] for i in order]
    groups=partition(indices,points,size)
    paths=[hierarchy(g,points,router,objective,size,stats) for g in groups]
    reps=[]
    for path in paths:
        center={'lat':sum(points[i]['lat'] for i in path)/len(path),'lon':sum(points[i]['lon'] for i in path)/len(path)}
        reps.append(min(path,key=lambda i:hav(points[i],center)))
    ordered_reps=hierarchy(reps,points,router,objective,size,stats)
    lookup={rep:j for j,rep in enumerate(reps)}
    return [i for rep in ordered_reps for i in paths[lookup[rep]]]

def optimize(args):
    started=time.perf_counter(); source=json.loads(pathlib.Path(args.input).read_text(encoding='utf-8'))
    points=source['points']
    if args.limit: points=points[:args.limit]
    if not points: raise ValueError('No POIs')
    if len({p['id'] for p in points})!=len(points): raise ValueError('Duplicate OSM IDs')
    if any(p['amenity'] not in KINDS or not -90<=p['lat']<=90 or not -180<=p['lon']<=180 for p in points): raise ValueError('Invalid POI')
    out=pathlib.Path(args.output); out.mkdir(parents=True,exist_ok=True)
    router=Router(args.osrm,out/'cache.sqlite',args.graph_version,args.delay)
    snapped=[]; rejected=[]
    for p in points:
        try:
            w=router.get('/nearest/v1/driving/'+router.coords([p])+'?number=1')['waypoints'][0]
            if w['distance']>args.max_snap: rejected.append(dict(p,reason='snap_too_far',snap_m=w['distance'])); continue
            snapped.append(dict(p,poi_lat=p['lat'],poi_lon=p['lon'],lon=w['location'][0],lat=w['location'][1],hint=w['hint'],snap_m=w['distance']))
        except RuntimeError as e: rejected.append(dict(p,reason=str(e)))
    write(out/'rejected.json',rejected)
    if rejected and not args.allow_partial: raise RuntimeError(f'{len(rejected)} POIs unsnappable; see rejected.json. Use --allow-partial only for an explicitly partial result.')
    points=snapped
    if not points: raise ValueError('No routable POIs')
    stats=[]; order=hierarchy(list(range(len(points))),points,router,args.objective,args.cluster_size,stats)
    # Route every directed edge, including closure. Global cut selects free endpoints.
    edges=[]
    if len(order)>1:
        for a,b in zip(order,order[1:]+order[:1]):
            r=router.route([points[a],points[b]])
            edges.append({'from':a,'to':b,'duration':r['duration'],'distance':r['distance'],'geometry':r['geometry']})
    if edges and not args.closed:
        cut=max(range(len(edges)),key=lambda i:edges[i][args.objective]); order=order[cut+1:]+order[:cut+1]; edges=edges[cut+1:]+edges[:cut]
    assert len(order)==len(points) and len(set(order))==len(points)
    result={'status':'REAL OSM SUBSET' if args.limit or source.get('scope')!='CZ administrative area' else ('PARTIAL CZ OSM' if rejected else 'CZ OSM SNAPSHOT'), 'source':{k:v for k,v in source.items() if k!='points'},'engine':args.osrm,'graph_version':args.graph_version,'objective':args.objective,'closed':args.closed,'optimality':'Heuristic feasible route; no certificate of global optimality. Free endpoints selected by largest-edge cut of hierarchical tour.', 'points':points,'order':order,'edges':edges,'metrics':{'input_count':len(source['points']),'selected_count':len(snapped)+len(rejected),'visited_count':len(order),'rejected_count':len(rejected),'coverage_selected':len(order)/(len(snapped)+len(rejected)),'distance_km':sum(e['distance'] for e in edges)/1000,'driving_hours':sum(e['duration'] for e in edges)/3600,'max_snap_m':max(p['snap_m'] for p in points),'elapsed_seconds':time.perf_counter()-started,'http_calls':router.calls,'cache_hits':router.hits,'cluster_size':args.cluster_size,'matrix_levels':stats}}
    result['computed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    result['selected_input_sha256']=hashlib.sha256(json.dumps(source['points'][:args.limit] if args.limit else source['points'],sort_keys=True).encode()).hexdigest()
    if source.get('synthetic'):
        result['status']='SYNTHETIC DEMO — NOT OSM OR REAL ROADS'
        result['optimality']+=' Invented POIs and directed model grid. Distances and times describe only that model.'
    write(out/'result.json',result)
    features=[{'type':'Feature','properties':{k:v for k,v in e.items() if k!='geometry'},'geometry':e['geometry']} for e in edges]
    write(out/'route.geojson',{'type':'FeatureCollection','features':features})
    template=pathlib.Path(__file__).with_name('map_template.html').read_text(encoding='utf-8')
    (out/'map.html').write_text(template.replace('__DATA__',json.dumps(result,ensure_ascii=False,allow_nan=False).replace('<','\\u003c')),encoding='utf-8')
    print(json.dumps(result['metrics'],ensure_ascii=False,indent=2),flush=True)

def main():
    parser=argparse.ArgumentParser(description=__doc__); sub=parser.add_subparsers(dest='command',required=True)
    f=sub.add_parser('fetch'); f.add_argument('--bbox'); f.add_argument('--overpass',default='https://overpass-api.de/api/interpreter'); f.add_argument('--output',default='pois.json'); f.set_defaults(func=fetch)
    o=sub.add_parser('optimize'); o.add_argument('--input',required=True); o.add_argument('--output',default='run'); o.add_argument('--osrm',default='http://127.0.0.1:5000'); o.add_argument('--graph-version',required=True,help='PBF date/hash and profile version; change to invalidate cache'); o.add_argument('--objective',choices=['duration','distance'],default='duration'); o.add_argument('--cluster-size',type=int,default=48); o.add_argument('--max-snap',type=float,default=250); o.add_argument('--limit',type=int); o.add_argument('--closed',action='store_true'); o.add_argument('--allow-partial',action='store_true'); o.add_argument('--delay',type=float,default=0); o.set_defaults(func=optimize)
    args=parser.parse_args()
    if args.command=='optimize' and (not 2<=args.cluster_size<=100 or args.max_snap<0 or (args.limit is not None and args.limit<1) or args.delay<0): parser.error('cluster-size 2..100, max-snap >=0, limit >=1, delay >=0')
    args.func(args)

if __name__=='__main__': main()
