import itertools, math, random, tempfile, unittest
from unittest.mock import patch
import pubroute as p

class OptimizationTests(unittest.TestCase):
    def test_asymmetric_relocation_monotone(self):
        rng=random.Random(14)
        for closed in [True,False]:
            for n in range(3,10):
                for _ in range(10):
                    m=[[0 if i==j else rng.randrange(1,300) for j in range(n)] for i in range(n)]
                    order=list(range(n)); rng.shuffle(order)
                    result=p.improve(order,m,closed)
                    self.assertEqual(sorted(result),list(range(n)))
                    self.assertLessEqual(p.cost(result,m,closed),p.cost(order,m,closed)+1e-7)
    def test_small_exact_reference(self):
        m=[[0,2,30,10],[11,0,3,40],[8,22,0,4],[5,7,50,0]]
        result,baseline,after=p.solve_matrix(m)
        optimum=min(p.cost(list(o),m) for o in itertools.permutations(range(4)))
        self.assertEqual(after,optimum); self.assertLessEqual(after,baseline)
    def test_disconnected_fails(self):
        with self.assertRaises(RuntimeError): p.solve_matrix([[0,math.inf],[math.inf,0]])
    def test_partition_and_recursive_coverage(self):
        pts=[{'id':str(i),'lon':14+i*.001,'lat':50+(i%7)*.01} for i in range(121)]
        groups=p.partition(list(range(len(pts))),pts,8)
        self.assertTrue(all(len(g)<=8 for g in groups))
        class Fake:
            def table(self,ps,objective): return [[p.hav(a,b) for b in ps] for a in ps]
        order=p.hierarchy(list(range(len(pts))),pts,Fake(),'distance',8,[])
        self.assertEqual(sorted(order),list(range(len(pts))))
    def test_cache_graph_version_and_nulls(self):
        import pathlib
        scratch=pathlib.Path(__file__).resolve().parent.parent/'work'
        scratch.mkdir(exist_ok=True)
        with tempfile.TemporaryDirectory(dir=scratch) as directory:
            with patch.object(p,'request',return_value={'code':'Ok','durations':[[0,None],[10,0]],'distances':[[0,None],[100,0]]}) as mock:
                pts=[{'lat':50,'lon':14},{'lat':50.1,'lon':14.1}]
                r=p.Router('http://localhost',directory+'/cache.sqlite','v1')
                self.assertEqual(r.table(pts,'duration')[0][1],math.inf)
                r.table(pts,'duration'); self.assertEqual(mock.call_count,1)
                r2=p.Router('http://localhost',directory+'/cache.sqlite','v2'); r2.table(pts,'duration')
                self.assertEqual(mock.call_count,2)
                r.db.close(); r2.db.close()

if __name__=='__main__': unittest.main(verbosity=2)
